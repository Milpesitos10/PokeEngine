"""Pruebas de normalización PokeAPI sin conexión de red ni SQL Server."""
from pokeengine_project import database, pokeapi


def _relations(**overrides):
    return {
        "no_damage_to": overrides.get("no_damage_to", []),
        "half_damage_to": overrides.get("half_damage_to", []),
        "double_damage_to": overrides.get("double_damage_to", []),
        "no_damage_from": overrides.get("no_damage_from", []),
        "half_damage_from": overrides.get("half_damage_from", []),
        "double_damage_from": overrides.get("double_damage_from", []),
    }


def _type_ref(name):
    return {"name": name, "url": f"https://pokeapi.co/api/v2/type/{name}/"}


def test_gen4_chart_has_all_pairs_and_uses_pre_fairy_relations():
    details = {
        name: {"damage_relations": _relations()}
        for name in database.GEN4_TYPES
    }
    details["steel"]["past_damage_relations"] = [{
        "generation": {"name": "generation-v"},
        "damage_relations": _relations(
            half_damage_from=[_type_ref("ghost"), _type_ref("dark")],
            double_damage_from=[_type_ref("fighting"), _type_ref("ground")],
            no_damage_from=[_type_ref("poison")],
        ),
    }]

    chart = pokeapi.gen4_type_chart(details)

    assert len(chart) == 289
    assert chart[("ghost", "steel")] == 0.5
    assert chart[("dark", "steel")] == 0.5
    assert chart[("fighting", "steel")] == 2.0
    assert chart[("poison", "steel")] == 0.0
    assert chart[("normal", "ghost")] == 1.0


def test_pokemon_moves_filters_by_diamond_pearl_and_platinum(monkeypatch):
    pokeapi._pokemon_move_refs.clear()
    monkeypatch.setattr(pokeapi, "_get", lambda _: {
        "moves": [
            {"move": {"name": "thunderbolt"}, "version_group_details": [
                {"version_group": {"name": "diamond-pearl"}},
            ]},
            {"move": {"name": "surf"}, "version_group_details": [
                {"version_group": {"name": "red-blue"}},
            ]},
        ],
    })
    monkeypatch.setattr(pokeapi, "move", lambda name: {
        "api_name": name, "name": name, "category": "special",
    })

    assert pokeapi.pokemon_moves(25) == [
        {"api_name": "thunderbolt", "name": "thunderbolt"}
    ]
    assert pokeapi.pokemon_moves(25, "thunderbolt")[0]["category"] == "special"
    assert pokeapi.pokemon_moves(25, "surf") == []


def test_move_builds_canonical_url_when_pokeapi_omits_it(monkeypatch):
    saved = []
    monkeypatch.setattr(pokeapi, "_get", lambda _: {
        "id": 87,
        "name": "thunder",
        "generation": {"name": "generation-i"},
        "past_values": [],
        "power": 110,
        "accuracy": 70,
        "pp": 10,
        "type": {"name": "electric", "url": "https://pokeapi.co/api/v2/type/13/"},
        "damage_class": {"name": "special"},
    })
    monkeypatch.setattr(database, "save_move", saved.append)

    result = pokeapi.move("thunder")

    assert result["api_name"] == "thunder"
    assert result["power"] == 110
    assert saved[0]["url"] == "https://pokeapi.co/api/v2/move/87/"
